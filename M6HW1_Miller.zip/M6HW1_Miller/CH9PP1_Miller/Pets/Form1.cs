﻿/**
* 13 May 2018
* CSC 153
* Jenica Miller
* Allows user to input pets info and display it
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pets
{
    public partial class Form1 : Form
    {
        pet pet = new pet();
        public Form1()
        {
            InitializeComponent();
        }
        private void getpetInfo (pet pet)
        {
            //set information of the pet in the class
            pet.Name = nameTextBox.Text;
            pet.Type = typeTextBox.Text;
            pet.Age = ageTextBox.Text;
        }
            private void enterButton_Click(object sender, EventArgs e)
        {
            string name = petName.Text;
            string type = petType.Text;
            string age = petAge.Text;
            
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            try
            {
                getpetInfo(pet);
                displayBox.Items.Add("Pet's name: " + pet.Name);
                displayBox.Items.Add("Pet's type: " + pet.Type);
                displayBox.Items.Add("Pet's age: " + pet.Age);
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Please enter the pets information");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear fields
            displayBox.Items.Clear();
            nameTextBox.Text = "";
            typeTextBox.Text = "";
            ageTextBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }
    }
}
