﻿namespace Pets
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.petName = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.petType = new System.Windows.Forms.Label();
            this.typeTextBox = new System.Windows.Forms.TextBox();
            this.petAge = new System.Windows.Forms.Label();
            this.ageTextBox = new System.Windows.Forms.TextBox();
            this.displayBox = new System.Windows.Forms.ListBox();
            this.enterButton = new System.Windows.Forms.Button();
            this.displayButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // petName
            // 
            this.petName.AutoSize = true;
            this.petName.Location = new System.Drawing.Point(32, 28);
            this.petName.Name = "petName";
            this.petName.Size = new System.Drawing.Size(61, 13);
            this.petName.TabIndex = 0;
            this.petName.Text = "Pet\'s Name";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(154, 20);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 1;
            // 
            // petType
            // 
            this.petType.AutoSize = true;
            this.petType.Location = new System.Drawing.Point(32, 66);
            this.petType.Name = "petType";
            this.petType.Size = new System.Drawing.Size(57, 13);
            this.petType.TabIndex = 2;
            this.petType.Text = "Pet\'s Type";
            // 
            // typeTextBox
            // 
            this.typeTextBox.Location = new System.Drawing.Point(154, 59);
            this.typeTextBox.Name = "typeTextBox";
            this.typeTextBox.Size = new System.Drawing.Size(100, 20);
            this.typeTextBox.TabIndex = 3;
            // 
            // petAge
            // 
            this.petAge.AutoSize = true;
            this.petAge.Location = new System.Drawing.Point(32, 111);
            this.petAge.Name = "petAge";
            this.petAge.Size = new System.Drawing.Size(52, 13);
            this.petAge.TabIndex = 4;
            this.petAge.Text = "Pet\'s Age";
            // 
            // ageTextBox
            // 
            this.ageTextBox.Location = new System.Drawing.Point(154, 108);
            this.ageTextBox.Name = "ageTextBox";
            this.ageTextBox.Size = new System.Drawing.Size(100, 20);
            this.ageTextBox.TabIndex = 5;
            // 
            // displayBox
            // 
            this.displayBox.FormattingEnabled = true;
            this.displayBox.Location = new System.Drawing.Point(35, 209);
            this.displayBox.Name = "displayBox";
            this.displayBox.Size = new System.Drawing.Size(219, 95);
            this.displayBox.TabIndex = 6;
            // 
            // enterButton
            // 
            this.enterButton.Location = new System.Drawing.Point(35, 154);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(75, 23);
            this.enterButton.TabIndex = 7;
            this.enterButton.Text = "Enter Data";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(179, 154);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 23);
            this.displayButton.TabIndex = 8;
            this.displayButton.Text = "Display Data";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(35, 326);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear Data";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(179, 326);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 388);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.enterButton);
            this.Controls.Add(this.displayBox);
            this.Controls.Add(this.ageTextBox);
            this.Controls.Add(this.petAge);
            this.Controls.Add(this.typeTextBox);
            this.Controls.Add(this.petType);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.petName);
            this.Name = "Form1";
            this.Text = "Pet";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label petName;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label petType;
        private System.Windows.Forms.TextBox typeTextBox;
        private System.Windows.Forms.Label petAge;
        private System.Windows.Forms.TextBox ageTextBox;
        private System.Windows.Forms.ListBox displayBox;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

