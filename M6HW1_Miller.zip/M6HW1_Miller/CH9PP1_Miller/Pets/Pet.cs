﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pets
{
    public class pet
    {
        //fields
        private string _name;
        private string _type;
        private string _age;
        
        //constructor
        public pet(string name, string type, string age)
        {
            _name = "";
            _type = "";
            _age = "";
        }
        public pet()
        {

        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }
        public string Age
        {
            get { return _age; }
            set { _age = value; }
        }
    }
}
