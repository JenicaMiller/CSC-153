﻿/**
* 13 May 2018
* CSC 153
* Jenica Miller
* Allows users to enter cars and then increase or decrease its speed
*/ 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarClassLibrary;

namespace CarClass
{
    public partial class Form1 : Form
    {
        // Creates an object of the car class
        
        Car car = new Car();
        public Form1()
        {
            InitializeComponent();
        }

        private void getCarInfo(Car car)
        {
            // Sets the information of the car in the class
            car.Year = yearTextBox.Text;
            car.Make = makeTextBox.Text;
            car.Speed = 0;
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            // Increases cars speed by 5
            speedLabel.Text = car.Accelerate.ToString();
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            // Decreases cars speed by 5
            speedLabel.Text = car.Brake.ToString();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Gets the information of the car
            getCarInfo(car);
            // Displays the cars output
            yearLabel.Text = car.Year;
            makeLabel.Text = car.Make;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears labels and textboxes on the form
            yearLabel.Text = "";
            makeLabel.Text = "";
            yearTextBox.Text = "";
            makeTextBox.Text = "";
            speedLabel.Text = "";
            car.Speed = 0;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
