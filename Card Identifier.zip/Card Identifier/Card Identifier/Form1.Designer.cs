﻿namespace Card_Identifier
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionalLabel = new System.Windows.Forms.Label();
            this.answerLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.queenofDimondspictureBox = new System.Windows.Forms.PictureBox();
            this.aceofClubspictureBox = new System.Windows.Forms.PictureBox();
            this.sevenofSpadepictureBox = new System.Windows.Forms.PictureBox();
            this.jokerpictureBox = new System.Windows.Forms.PictureBox();
            this.queenofSpadespictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.queenofDimondspictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceofClubspictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevenofSpadepictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jokerpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenofSpadespictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // instructionalLabel
            // 
            this.instructionalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionalLabel.Location = new System.Drawing.Point(69, 36);
            this.instructionalLabel.Name = "instructionalLabel";
            this.instructionalLabel.Size = new System.Drawing.Size(417, 26);
            this.instructionalLabel.TabIndex = 0;
            this.instructionalLabel.Text = "Click a card to See Its Name";
            this.instructionalLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // answerLabel
            // 
            this.answerLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.answerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerLabel.Location = new System.Drawing.Point(114, 303);
            this.answerLabel.Name = "answerLabel";
            this.answerLabel.Size = new System.Drawing.Size(372, 49);
            this.answerLabel.TabIndex = 1;
            this.answerLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(262, 398);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "EXIT";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // queenofDimondspictureBox
            // 
            this.queenofDimondspictureBox.Image = global::Card_Identifier.Properties.Resources.queen_diamonds;
            this.queenofDimondspictureBox.Location = new System.Drawing.Point(121, 124);
            this.queenofDimondspictureBox.Name = "queenofDimondspictureBox";
            this.queenofDimondspictureBox.Size = new System.Drawing.Size(100, 129);
            this.queenofDimondspictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.queenofDimondspictureBox.TabIndex = 4;
            this.queenofDimondspictureBox.TabStop = false;
            this.queenofDimondspictureBox.Click += new System.EventHandler(this.queenofDimondspictureBox_Click);
            // 
            // aceofClubspictureBox
            // 
            this.aceofClubspictureBox.Image = global::Card_Identifier.Properties.Resources._2000px_Playing_card_club_A_svg;
            this.aceofClubspictureBox.Location = new System.Drawing.Point(15, 124);
            this.aceofClubspictureBox.Name = "aceofClubspictureBox";
            this.aceofClubspictureBox.Size = new System.Drawing.Size(100, 129);
            this.aceofClubspictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.aceofClubspictureBox.TabIndex = 3;
            this.aceofClubspictureBox.TabStop = false;
            this.aceofClubspictureBox.Click += new System.EventHandler(this.aceofClubspictureBox_Click);
            // 
            // sevenofSpadepictureBox
            // 
            this.sevenofSpadepictureBox.Image = global::Card_Identifier.Properties.Resources.Playing_card_spade_7_svg;
            this.sevenofSpadepictureBox.Location = new System.Drawing.Point(227, 124);
            this.sevenofSpadepictureBox.Name = "sevenofSpadepictureBox";
            this.sevenofSpadepictureBox.Size = new System.Drawing.Size(100, 129);
            this.sevenofSpadepictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sevenofSpadepictureBox.TabIndex = 5;
            this.sevenofSpadepictureBox.TabStop = false;
            this.sevenofSpadepictureBox.Click += new System.EventHandler(this.sevenofSpadepictureBox_Click);
            // 
            // jokerpictureBox
            // 
            this.jokerpictureBox.Image = global::Card_Identifier.Properties.Resources.joker_playing_card_by_roadkill0313_datceig;
            this.jokerpictureBox.Location = new System.Drawing.Point(333, 124);
            this.jokerpictureBox.Name = "jokerpictureBox";
            this.jokerpictureBox.Size = new System.Drawing.Size(100, 129);
            this.jokerpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.jokerpictureBox.TabIndex = 6;
            this.jokerpictureBox.TabStop = false;
            this.jokerpictureBox.Click += new System.EventHandler(this.jokerpictureBox_Click);
            // 
            // queenofSpadespictureBox
            // 
            this.queenofSpadespictureBox.Image = global::Card_Identifier.Properties.Resources.QS;
            this.queenofSpadespictureBox.Location = new System.Drawing.Point(439, 124);
            this.queenofSpadespictureBox.Name = "queenofSpadespictureBox";
            this.queenofSpadespictureBox.Size = new System.Drawing.Size(100, 129);
            this.queenofSpadespictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.queenofSpadespictureBox.TabIndex = 7;
            this.queenofSpadespictureBox.TabStop = false;
            this.queenofSpadespictureBox.Click += new System.EventHandler(this.queenofSpadespictureBox_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 452);
            this.Controls.Add(this.queenofSpadespictureBox);
            this.Controls.Add(this.jokerpictureBox);
            this.Controls.Add(this.sevenofSpadepictureBox);
            this.Controls.Add(this.queenofDimondspictureBox);
            this.Controls.Add(this.aceofClubspictureBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.answerLabel);
            this.Controls.Add(this.instructionalLabel);
            this.Name = "Form1";
            this.Text = "cardIdentifier";
            ((System.ComponentModel.ISupportInitialize)(this.queenofDimondspictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceofClubspictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevenofSpadepictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jokerpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenofSpadespictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label instructionalLabel;
        private System.Windows.Forms.Label answerLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox aceofClubspictureBox;
        private System.Windows.Forms.PictureBox queenofDimondspictureBox;
        private System.Windows.Forms.PictureBox sevenofSpadepictureBox;
        private System.Windows.Forms.PictureBox jokerpictureBox;
        private System.Windows.Forms.PictureBox queenofSpadespictureBox;
    }
}

