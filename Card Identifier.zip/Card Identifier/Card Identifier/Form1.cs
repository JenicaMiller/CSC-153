﻿/**
* February 1, 2018
* CSC 153
* Jenica Miller
* Indentify the Card by Name
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Card_Identifier
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void aceofClubspictureBox_Click(object sender, EventArgs e)
        {
            answerLabel.Text = "Ace of Clubs";
        }

        private void queenofDimondspictureBox_Click(object sender, EventArgs e)
        {
            answerLabel.Text = "Queen of Diamonds";
        }

        private void sevenofSpadepictureBox_Click(object sender, EventArgs e)
        {
            answerLabel.Text = "Seven of Spades";
        }

        private void jokerpictureBox_Click(object sender, EventArgs e)
        {
            answerLabel.Text = "Joker";
        }

        private void queenofSpadespictureBox_Click(object sender, EventArgs e)
        {
            answerLabel.Text = "Queen of Spades";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();   
        }
    }
}
