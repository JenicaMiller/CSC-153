﻿/**
* 4 May 2018
* CSC 153
* Jenica Miller
* Falling distance
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Falling_Distance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
           //Calculate the distance
            double distanceValue;
            double time;
            
            time = double.Parse(secondsTextBox.Text);
            
            distanceValue = FallingDistance(time);
           
            MessageBox.Show("The distance the object has fallen is "
                + distanceValue + " meters.");
        }
            
         private double FallingDistance(double time)
        {
           return 0.5 * 9.8 * (time*=time);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear text box
            secondsTextBox.Text = "";
        }
    }
}