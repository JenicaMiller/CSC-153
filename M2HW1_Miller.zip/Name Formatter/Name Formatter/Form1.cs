﻿/**
* 15 February 2018
* CSC 153
* Jenica Miller
* Formats name in six different ways
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Name_Formatter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void nameFormatterButton_Click(object sender, EventArgs e)
        {
            //declare variables 
            string firstName;
            string middleName;
            string lastName;
            string title;

            firstName = firstNameTextBox.Text;
            middleName = middleNameTextBox.Text;
            lastName = lastNameTextBox.Text;
            title = titleTextBox.Text;

            //Adding items to the list box with the form needed to display the name
            output.Items.Add(title + " " + firstName + " " + middleName + " " + lastName);
            output.Items.Add(firstName + " "+ middleName + " " + lastName);
            output.Items.Add(firstName + " " + lastName);
            output.Items.Add(lastName + ", " + firstName + " " + middleName + ", " + title);
            output.Items.Add(lastName + ", " + firstName + " " + middleName);
            output.Items.Add(lastName + ", " + firstName);
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear the TextBox and ListBox Controls
            firstNameTextBox.Text = " ";
            middleNameTextBox.Text = " ";
            lastNameTextBox.Text = " ";
            titleTextBox.Text = " ";
            output.Items.Clear();

            //Set ther focus to firstNameTextBox
            firstNameTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
