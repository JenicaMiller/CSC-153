﻿/**
* March 20, 2018
* CSC 153
* Jenica Miller
* Calculate the approximate size of a population of organisms
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Organisms_Population
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Declare variables
            double numberOrganisms;  //number of organisms
            double dailyIncrease;   //daily increase
            int numberDays;   //how many days
            int count = 1;  //count varible

            if (double.TryParse(numberOrganismTextBox.Text, out numberOrganisms)
                && double.TryParse(dailyIncreaseTextBox.Text, out dailyIncrease)
                && int.TryParse(numberDaysTextBox.Text, out numberDays))
            {
                resultsListBox.Items.Add("Day          Approximate Populations");
                // dailyIncrease is considered as a %
                dailyIncrease /= 100;
                while (count <= numberDays)
                {
                    resultsListBox.Items.Add(count + "             " + numberOrganisms);
                    count = count + 1;
                    numberOrganisms += numberOrganisms * dailyIncrease;
                }
            }
            else
            {
                MessageBox.Show("Error, please try again!");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear out the results and put the cursor in the "Starting number of organisms" text box
            numberOrganismTextBox.Clear(); dailyIncreaseTextBox.Clear(); numberDaysTextBox.Clear();
            resultsListBox.Items.Clear(); numberOrganismTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close this form
            this.Close();
        }
    }
}
