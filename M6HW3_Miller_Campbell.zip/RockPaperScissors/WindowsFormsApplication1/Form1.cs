﻿//29 April 2018
//CSC-153
//Miller, Campbell-Brown
//Rock Paper Scissor
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int playerScore, computerScore = 0;
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Rock
            playRound(1);
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //Paper
            playRound(2);
        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            //Scissors
            playRound(3);
        }
        private void resetButton_Click(object sender, EventArgs e)
        {
            //Reset
            playerScore = 0;
            computerScore = 0;
            playerPicBox.Image = null;
            computerPicBox.Image = null;
            stateLabel.Text = "Reset Game";
            playerScoreLabel.Text = "0";
            computerScoreLabel.Text = "0";
        }
        private void playRound(int selection)
        {
            Random rand = new Random();
            int computerSelection = rand.Next(1, 4);
            SetImage(playerPicBox, selection);
            SetImage(computerPicBox, computerSelection);
            if(computerSelection == selection)
            {
                stateLabel.Text = "DRAW";
                return;
            }
            switch (selection)
            {
                case 1:
                    if (computerSelection == 2)
                        updateScore(true);
                    else
                        updateScore(false);
                    break;

                case 2:
                    if (computerSelection == 3)
                        updateScore(true);
                    else
                        updateScore(false);
                    break;
                case 3:
                    if (computerSelection == 1)
                        updateScore(true);
                    else
                        updateScore(false);
                    break;
            }
        }
    private void updateScore(bool playerWon)
    {
        if (playerWon)
        {
            playerScore++;
            stateLabel.Text = "WIN";
            playerScoreLabel.Text = playerScore.ToString();
        }
        else
        {
            computerScore++;
            stateLabel.Text = "LOSE";
            computerScoreLabel.Text = computerScore.ToString();
        }
    }
        private void SetImage(PictureBox pd, int img)
        {
            if (img == 1)
                pd.Image = Properties.Resources.Rock;
            else if (img == 2)
                pd.Image = Properties.Resources.Paper;
            else if (img == 3)
                pd.Image = Properties.Resources.Scissors;
        }
    }
}
