﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scissorPicBox = new System.Windows.Forms.PictureBox();
            this.paperPicBox = new System.Windows.Forms.PictureBox();
            this.rockPicBox = new System.Windows.Forms.PictureBox();
            this.playerLabel = new System.Windows.Forms.Label();
            this.cptLabel = new System.Windows.Forms.Label();
            this.playerPicBox = new System.Windows.Forms.PictureBox();
            this.computerPicBox = new System.Windows.Forms.PictureBox();
            this.resetButton = new System.Windows.Forms.Button();
            this.playerScoreLabel = new System.Windows.Forms.Label();
            this.computerScoreLabel = new System.Windows.Forms.Label();
            this.stateLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.scissorPicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rockPicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerPicBox)).BeginInit();
            this.SuspendLayout();
            // 
            // scissorPicBox
            // 
            this.scissorPicBox.Image = global::WindowsFormsApplication1.Properties.Resources.Scissors;
            this.scissorPicBox.Location = new System.Drawing.Point(398, 309);
            this.scissorPicBox.Name = "scissorPicBox";
            this.scissorPicBox.Size = new System.Drawing.Size(128, 121);
            this.scissorPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.scissorPicBox.TabIndex = 2;
            this.scissorPicBox.TabStop = false;
            this.scissorPicBox.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // paperPicBox
            // 
            this.paperPicBox.Image = global::WindowsFormsApplication1.Properties.Resources.Paper;
            this.paperPicBox.Location = new System.Drawing.Point(398, 160);
            this.paperPicBox.Name = "paperPicBox";
            this.paperPicBox.Size = new System.Drawing.Size(128, 121);
            this.paperPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.paperPicBox.TabIndex = 1;
            this.paperPicBox.TabStop = false;
            this.paperPicBox.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // rockPicBox
            // 
            this.rockPicBox.Image = global::WindowsFormsApplication1.Properties.Resources.Rock;
            this.rockPicBox.Location = new System.Drawing.Point(407, 12);
            this.rockPicBox.Name = "rockPicBox";
            this.rockPicBox.Size = new System.Drawing.Size(128, 121);
            this.rockPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.rockPicBox.TabIndex = 0;
            this.rockPicBox.TabStop = false;
            this.rockPicBox.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // playerLabel
            // 
            this.playerLabel.AutoSize = true;
            this.playerLabel.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerLabel.Location = new System.Drawing.Point(12, 161);
            this.playerLabel.Name = "playerLabel";
            this.playerLabel.Size = new System.Drawing.Size(77, 20);
            this.playerLabel.TabIndex = 3;
            this.playerLabel.Text = "Player";
            // 
            // cptLabel
            // 
            this.cptLabel.AutoSize = true;
            this.cptLabel.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cptLabel.Location = new System.Drawing.Point(199, 160);
            this.cptLabel.Name = "cptLabel";
            this.cptLabel.Size = new System.Drawing.Size(107, 20);
            this.cptLabel.TabIndex = 4;
            this.cptLabel.Text = "Computer";
            // 
            // playerPicBox
            // 
            this.playerPicBox.Location = new System.Drawing.Point(12, 184);
            this.playerPicBox.Name = "playerPicBox";
            this.playerPicBox.Size = new System.Drawing.Size(128, 121);
            this.playerPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerPicBox.TabIndex = 5;
            this.playerPicBox.TabStop = false;
            // 
            // computerPicBox
            // 
            this.computerPicBox.Location = new System.Drawing.Point(203, 184);
            this.computerPicBox.Name = "computerPicBox";
            this.computerPicBox.Size = new System.Drawing.Size(128, 121);
            this.computerPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.computerPicBox.TabIndex = 6;
            this.computerPicBox.TabStop = false;
            // 
            // resetButton
            // 
            this.resetButton.Font = new System.Drawing.Font("Perpetua Titling MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetButton.Location = new System.Drawing.Point(64, 363);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(201, 67);
            this.resetButton.TabIndex = 7;
            this.resetButton.Text = "Reset Game";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // playerScoreLabel
            // 
            this.playerScoreLabel.AutoSize = true;
            this.playerScoreLabel.Font = new System.Drawing.Font("Perpetua Titling MT", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerScoreLabel.Location = new System.Drawing.Point(46, 318);
            this.playerScoreLabel.Name = "playerScoreLabel";
            this.playerScoreLabel.Size = new System.Drawing.Size(14, 13);
            this.playerScoreLabel.TabIndex = 8;
            this.playerScoreLabel.Text = "0";
            // 
            // computerScoreLabel
            // 
            this.computerScoreLabel.AutoSize = true;
            this.computerScoreLabel.Font = new System.Drawing.Font("Perpetua Titling MT", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.computerScoreLabel.Location = new System.Drawing.Point(227, 318);
            this.computerScoreLabel.Name = "computerScoreLabel";
            this.computerScoreLabel.Size = new System.Drawing.Size(14, 13);
            this.computerScoreLabel.TabIndex = 9;
            this.computerScoreLabel.Text = "0";
            // 
            // stateLabel
            // 
            this.stateLabel.AutoSize = true;
            this.stateLabel.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stateLabel.Location = new System.Drawing.Point(133, 119);
            this.stateLabel.Name = "stateLabel";
            this.stateLabel.Size = new System.Drawing.Size(65, 20);
            this.stateLabel.TabIndex = 10;
            this.stateLabel.Text = "State:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 442);
            this.Controls.Add(this.stateLabel);
            this.Controls.Add(this.computerScoreLabel);
            this.Controls.Add(this.playerScoreLabel);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.computerPicBox);
            this.Controls.Add(this.playerPicBox);
            this.Controls.Add(this.cptLabel);
            this.Controls.Add(this.playerLabel);
            this.Controls.Add(this.scissorPicBox);
            this.Controls.Add(this.paperPicBox);
            this.Controls.Add(this.rockPicBox);
            this.Name = "Form1";
            this.Text = "Rock Paper Scissors";
            ((System.ComponentModel.ISupportInitialize)(this.scissorPicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rockPicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerPicBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox rockPicBox;
        private System.Windows.Forms.PictureBox paperPicBox;
        private System.Windows.Forms.PictureBox scissorPicBox;
        private System.Windows.Forms.Label playerLabel;
        private System.Windows.Forms.Label cptLabel;
        private System.Windows.Forms.PictureBox playerPicBox;
        private System.Windows.Forms.PictureBox computerPicBox;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Label playerScoreLabel;
        private System.Windows.Forms.Label computerScoreLabel;
        private System.Windows.Forms.Label stateLabel;
    }
}

