﻿namespace Software_Sales
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numberLabel = new System.Windows.Forms.Label();
            this.discountLabel = new System.Windows.Forms.Label();
            this.disLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.grandTotalLabel = new System.Windows.Forms.Label();
            this.totalButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.packagesTextBox = new System.Windows.Forms.TextBox();
            this.subtotalLabel = new System.Windows.Forms.Label();
            this.subLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(35, 33);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(110, 13);
            this.numberLabel.TabIndex = 0;
            this.numberLabel.Text = "Number of Packages:";
            // 
            // discountLabel
            // 
            this.discountLabel.AutoSize = true;
            this.discountLabel.Location = new System.Drawing.Point(64, 120);
            this.discountLabel.Name = "discountLabel";
            this.discountLabel.Size = new System.Drawing.Size(80, 13);
            this.discountLabel.TabIndex = 2;
            this.discountLabel.Text = "Percentage off:";
            // 
            // disLabel
            // 
            this.disLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.disLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.disLabel.Location = new System.Drawing.Point(151, 117);
            this.disLabel.Name = "disLabel";
            this.disLabel.Size = new System.Drawing.Size(100, 23);
            this.disLabel.TabIndex = 3;
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(22, 153);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(122, 13);
            this.totalLabel.TabIndex = 4;
            this.totalLabel.Text = "Total including discount:";
            // 
            // grandTotalLabel
            // 
            this.grandTotalLabel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.grandTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.grandTotalLabel.Location = new System.Drawing.Point(151, 153);
            this.grandTotalLabel.Name = "grandTotalLabel";
            this.grandTotalLabel.Size = new System.Drawing.Size(100, 23);
            this.grandTotalLabel.TabIndex = 5;
            // 
            // totalButton
            // 
            this.totalButton.Location = new System.Drawing.Point(25, 199);
            this.totalButton.Name = "totalButton";
            this.totalButton.Size = new System.Drawing.Size(75, 23);
            this.totalButton.TabIndex = 6;
            this.totalButton.Text = "Total";
            this.totalButton.UseVisualStyleBackColor = true;
            this.totalButton.Click += new System.EventHandler(this.totalButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(106, 199);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 7;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(188, 198);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // packagesTextBox
            // 
            this.packagesTextBox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.packagesTextBox.Location = new System.Drawing.Point(151, 30);
            this.packagesTextBox.Name = "packagesTextBox";
            this.packagesTextBox.Size = new System.Drawing.Size(100, 20);
            this.packagesTextBox.TabIndex = 9;
            // 
            // subtotalLabel
            // 
            this.subtotalLabel.AutoSize = true;
            this.subtotalLabel.Location = new System.Drawing.Point(95, 79);
            this.subtotalLabel.Name = "subtotalLabel";
            this.subtotalLabel.Size = new System.Drawing.Size(49, 13);
            this.subtotalLabel.TabIndex = 10;
            this.subtotalLabel.Text = "Subtotal:";
            // 
            // subLabel
            // 
            this.subLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.subLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.subLabel.Location = new System.Drawing.Point(151, 78);
            this.subLabel.Name = "subLabel";
            this.subLabel.Size = new System.Drawing.Size(100, 23);
            this.subLabel.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.subLabel);
            this.Controls.Add(this.subtotalLabel);
            this.Controls.Add(this.packagesTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.totalButton);
            this.Controls.Add(this.grandTotalLabel);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.disLabel);
            this.Controls.Add(this.discountLabel);
            this.Controls.Add(this.numberLabel);
            this.Name = "Form1";
            this.Text = "Software Sales";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.Label discountLabel;
        private System.Windows.Forms.Label disLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label grandTotalLabel;
        private System.Windows.Forms.Button totalButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox packagesTextBox;
        private System.Windows.Forms.Label subtotalLabel;
        private System.Windows.Forms.Label subLabel;
    }
}

