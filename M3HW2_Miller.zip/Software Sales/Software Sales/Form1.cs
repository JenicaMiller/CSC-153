﻿/** 
* 1 March 2018 
* CSC 153 
* Jenica Miller 
* This program computes the total cost of the purchase 
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void totalButton_Click(object sender, EventArgs e)
        {

            //try
            // {
            //
            double subtotal,
                   total,
                   packagePrice = 99,
                   discountAmount = 0;

                int numberPackages;
                int.TryParse(packagesTextBox.Text, out numberPackages);
          
            //Determine the discount
            if (numberPackages < 10)
                {
                    disLabel.Text = "0%";
                }
                else if (numberPackages < 20)
                {
                    discountAmount = (packagePrice * numberPackages / .100)  *.02;
                    disLabel.Text = "20%"; 
                }
                else if (numberPackages < 50)
                {
                    discountAmount = (packagePrice * numberPackages / .100) * .03;
                    disLabel.Text = "30%";
                }
                else if (numberPackages < 100)
                {
                    discountAmount = (packagePrice * numberPackages / .100) * .04;
                    disLabel.Text = "40%";
                }
                else
                {
                    discountAmount = (packagePrice * numberPackages / .100) * .05;
                    disLabel.Text = "50%";
                }

            //Calculate the price with discount if any
             subtotal = packagePrice * numberPackages;
             total = subtotal - discountAmount;

            //Display total price of purchase
            grandTotalLabel.Text = total.ToString("c");
            subLabel.Text = subtotal.ToString("c");
           
                
            //}
            //catch (Exception ex)
            //{
            //    //Display an error message.
            //    MessageBox.Show(ex.Message);
            //}
           
    }

        private void resetButton_Click(object sender, EventArgs e)
        {
            //Clear the label holding the final total
            packagesTextBox.Text = "";
            disLabel.Text = "";
            grandTotalLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
