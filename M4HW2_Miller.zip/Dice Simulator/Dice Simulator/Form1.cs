﻿/**
* March 25, 2018
* CSC 153
* Jenica Miller
* Random Dice Simulator.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Simulator
{
    public partial class diceSimulator : Form
    {
        public diceSimulator()
        {
            InitializeComponent();
        }

        private void rollButton_Click(object sender, EventArgs e)
        {
            //Create a Random object
            Random rand = new Random();

            //Get a random index
            int index = rand.Next(dieImageList.Images.Count);
            int index2 = rand.Next(dieImageList.Images.Count);

            //Display dice image in the picture boxes
            dice1PictureBox.Image = dieImageList.Images[index];
            dice2PictureBox.Image = dieImageList.Images[index2];
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Exit for
            this.Close();
        }
    }
}
