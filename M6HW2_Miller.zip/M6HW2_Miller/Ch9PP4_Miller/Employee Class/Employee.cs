﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Class
{
    class Employee
    {
        // Fields for the Employee Class.
        private string _name;
        private decimal _idNumber;
        private string _department;
        private string _position;

        // Constructor for default values.
        public Employee()
        {
            _name = "";
            _idNumber = 0;
            _department = "";
            _position = "";
        }

        // Constructor to set the name, idNumber, department, position.
        public Employee(string name, decimal idNumber, string department, string position)
        {
            _name = name;
            _idNumber = idNumber;
            _department = department;
            _position = position;
        }

        // Constructor to set empty department and position.
        public Employee(string name, decimal idNumber)
        {
            _name = name;
            _idNumber = idNumber;
            _department = "";
            _position = "";
        }

        // Set & Get for Name Property.
        public string Name
        {
            set { _name = value; }
            get { return _name; }
        }

        // Set & Get for ID Number Property.
        public decimal idNumber
        {
            set { _idNumber = value; }
            get { return _idNumber; }
        }

        // Set & Get for Department Property.
        public string Department
        {
            set { _department = value; }
            get { return _department; }
        }

        // Set & Get for Position Property.
        public string Position
        {
            set { _position = value; }
            get { return _position; }
        }
    }
}
