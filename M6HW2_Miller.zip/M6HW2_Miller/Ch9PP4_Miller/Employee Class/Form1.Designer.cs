﻿namespace Employee_Class
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employeeInfoLabel = new System.Windows.Forms.Label();
            this.firstEmployeeLabel = new System.Windows.Forms.Label();
            this.secondEmployeeLabel = new System.Windows.Forms.Label();
            this.thirdEmployeeLabel = new System.Windows.Forms.Label();
            this.firstEmployTextBox = new System.Windows.Forms.TextBox();
            this.secondEmployTextBox = new System.Windows.Forms.TextBox();
            this.thirdEmployTextBox = new System.Windows.Forms.TextBox();
            this.displayButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // employeeInfoLabel
            // 
            this.employeeInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeInfoLabel.Location = new System.Drawing.Point(199, 9);
            this.employeeInfoLabel.Name = "employeeInfoLabel";
            this.employeeInfoLabel.Size = new System.Drawing.Size(198, 23);
            this.employeeInfoLabel.TabIndex = 0;
            this.employeeInfoLabel.Text = "Employee Information";
            // 
            // firstEmployeeLabel
            // 
            this.firstEmployeeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstEmployeeLabel.Location = new System.Drawing.Point(12, 64);
            this.firstEmployeeLabel.Name = "firstEmployeeLabel";
            this.firstEmployeeLabel.Size = new System.Drawing.Size(100, 23);
            this.firstEmployeeLabel.TabIndex = 1;
            this.firstEmployeeLabel.Text = "Employee #1";
            // 
            // secondEmployeeLabel
            // 
            this.secondEmployeeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secondEmployeeLabel.Location = new System.Drawing.Point(12, 109);
            this.secondEmployeeLabel.Name = "secondEmployeeLabel";
            this.secondEmployeeLabel.Size = new System.Drawing.Size(100, 23);
            this.secondEmployeeLabel.TabIndex = 2;
            this.secondEmployeeLabel.Text = "Employee #2";
            // 
            // thirdEmployeeLabel
            // 
            this.thirdEmployeeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thirdEmployeeLabel.Location = new System.Drawing.Point(12, 153);
            this.thirdEmployeeLabel.Name = "thirdEmployeeLabel";
            this.thirdEmployeeLabel.Size = new System.Drawing.Size(100, 23);
            this.thirdEmployeeLabel.TabIndex = 3;
            this.thirdEmployeeLabel.Text = "Employee #3";
            // 
            // firstEmployTextBox
            // 
            this.firstEmployTextBox.Location = new System.Drawing.Point(119, 64);
            this.firstEmployTextBox.Name = "firstEmployTextBox";
            this.firstEmployTextBox.Size = new System.Drawing.Size(394, 20);
            this.firstEmployTextBox.TabIndex = 4;
            // 
            // secondEmployTextBox
            // 
            this.secondEmployTextBox.Location = new System.Drawing.Point(119, 109);
            this.secondEmployTextBox.Name = "secondEmployTextBox";
            this.secondEmployTextBox.Size = new System.Drawing.Size(394, 20);
            this.secondEmployTextBox.TabIndex = 5;
            // 
            // thirdEmployTextBox
            // 
            this.thirdEmployTextBox.Location = new System.Drawing.Point(119, 153);
            this.thirdEmployTextBox.Name = "thirdEmployTextBox";
            this.thirdEmployTextBox.Size = new System.Drawing.Size(394, 20);
            this.thirdEmployTextBox.TabIndex = 6;
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(203, 199);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(93, 39);
            this.displayButton.TabIndex = 7;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(304, 199);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(93, 39);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(599, 267);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.thirdEmployTextBox);
            this.Controls.Add(this.secondEmployTextBox);
            this.Controls.Add(this.firstEmployTextBox);
            this.Controls.Add(this.thirdEmployeeLabel);
            this.Controls.Add(this.secondEmployeeLabel);
            this.Controls.Add(this.firstEmployeeLabel);
            this.Controls.Add(this.employeeInfoLabel);
            this.Name = "MainForm";
            this.Text = "Employee Class";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label employeeInfoLabel;
        private System.Windows.Forms.Label firstEmployeeLabel;
        private System.Windows.Forms.Label secondEmployeeLabel;
        private System.Windows.Forms.Label thirdEmployeeLabel;
        private System.Windows.Forms.TextBox firstEmployTextBox;
        private System.Windows.Forms.TextBox secondEmployTextBox;
        private System.Windows.Forms.TextBox thirdEmployTextBox;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Button exitButton;
    }
}

