﻿/**
* 14 May 2018
* CSC 153
* Jenica Miller
* Uses aclass with overloaded constructors to hold employee info
* 
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Class
{
    public partial class MainForm : Form
    {

        // Creation of three instances of the Employee Class.
        private Employee employee1 = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");
        private Employee employee2 = new Employee("Mark Jones", 39199, "IT", "Programmer");
        private Employee employee3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");

        public MainForm()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Button Click event calls the three employee objects and sets the values for each.
            // Display first employee information.
            firstEmployTextBox.Text = employee1.Name + ", " + employee1.idNumber + ", " + employee1.Department + ", " + employee1.Position;
            // Display second employee information.
            secondEmployTextBox.Text = employee2.Name + ", " + employee2.idNumber + ", " + employee2.Department + ", " + employee2.Position;
            // Display third employee information.
            thirdEmployTextBox.Text = employee3.Name + ", " + employee3.idNumber + ", " + employee3.Department + ", " + employee3.Position;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form.
            this.Close();
        }
    }
}