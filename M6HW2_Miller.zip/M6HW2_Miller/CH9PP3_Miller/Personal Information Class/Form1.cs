﻿/**
* 14 May 2018
* CSC 153
* Jenica Miller
* Use a class and array to display personal infon loaded into
* the form.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Personal_Information_Class
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        // Array reference for Individual class
        private Individual[] familyMem = new Individual[4];

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Form Load event to initialize an array reference for all members of the family.
            // Properties for object at Index 0.
            familyMem[0] = new Individual();
            familyMem[0].Name = "Jenica Miller";
            familyMem[0].Address = "Cameron, NC";
            familyMem[0].Age = 43;
            familyMem[0].PhoneNumber = "757-777-9311";

            // Properties for object at Index 1.
            familyMem[1] = new Individual();
            familyMem[1].Name = "Deborah Miller";
            familyMem[1].Address = "Spartanburg, SC";
            familyMem[1].Age = 67;
            familyMem[1].PhoneNumber = "757-757-7575";

            // Properties for object at Index 2.
            familyMem[2] = new Individual();
            familyMem[2].Name = "Jimmie Miller";
            familyMem[2].Address = "Kansas City, MO";
            familyMem[2].Age = 68;
            familyMem[2].PhoneNumber = "352-352-3523";

            // Properties for object at Index 3.
            familyMem[3] = new Individual();
            familyMem[3].Name = "Toneya Miller";
            familyMem[3].Address = "Chesapeak, VA";
            familyMem[3].Age = 47;
            familyMem[3].PhoneNumber = "757-123-4567";
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Display information to corresponding text boxes.
            // My Info
            myInfoTextBox.Text = familyMem[0].Name + ", " + familyMem[0].Address + ", " + familyMem[0].Age + ", " + familyMem[0].PhoneNumber;
            // Mother's Info
            mothersInfoTextBox.Text = familyMem[1].Name + ", " + familyMem[1].Address + ", " + familyMem[1].Age + ", " + familyMem[1].PhoneNumber;
            // Father's Info
            fathersInfoTextBox.Text = familyMem[2].Name + ", " + familyMem[2].Address + ", " + familyMem[2].Age + ", " + familyMem[2].PhoneNumber;
            // Sister's Info
            sistersInfoTextBox.Text = familyMem[3].Name + ", " + familyMem[3].Address + ", " + familyMem[3].Age + ", " + familyMem[3].PhoneNumber;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form.
            this.Close();
        }
    }
}
