﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personal_Information_Class
{
    class Individual
    {
        //Fields for Class.
        private string _name;
        private string _address;
        private int _age;
        private string _phoneNumber;

        //Name Property.
        public String Name
        {
            set { _name = value; }
            get { return _name; }
        }

        //Address Property.
        public String Address
        {
            set { _address = value; }
            get { return _address; }
        }

        //Age Property.
        public int Age
        {
            set { _age = value; }
            get { return _age; }
        }

        //Phone Number Property.
        public string PhoneNumber
        {
            set { _phoneNumber = value; }
            get { return _phoneNumber; }
        }
    }
}
