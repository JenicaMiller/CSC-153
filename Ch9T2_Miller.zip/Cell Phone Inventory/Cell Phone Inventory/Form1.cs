﻿/**
* 3 May 2018
* CSC 153
* Jenica Miller
* Completeing the Cell Phone Inventory Application
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Cell_Phone_Inventory
{
    public partial class Form1 : Form
    {
        //List to hold CellPhone objets
        List<CellPhone> phonelist = new List<CellPhone>();
        public Form1()
        {
            InitializeComponent();
        }
        //The GetPhoneData method accepts a CellPhone object as an
        //argument.  It assigns the data enteed by the user to the
        //object's properties.
        private void GetPhoneData (CellPhone phone)
        {
            //Temporary variables to hold the price.
            decimal price;

            //Get the phone's brand.
            phone.Brand = brandTextBox.Text;

            //Get the phone's model.
            phone.Model = modelTextBox.Text;

            //Get the phone's price.
            if (decimal.TryParse (priceTextBox.Text, out price))
            {
                phone.Price = price;
            }
            else
            {
                //Display an error message.
                MessageBox.Show("Invalid price");
            }
        }

        private void addPhoneButton_Click(object sender, EventArgs e)
        {
            //Create a CellPhone object.
            CellPhone myphone = new CellPhone();

            //Get the phone data.
            GetPhoneData(myphone);

            //Add the CellPhone object to the List.
            phonelist.Add(myphone);

            //Add an entry to the list box.
            phoneListBox.Items.Add(myphone.Brand + " " + myphone.Model);

            //Clear the TextBox controls.
            brandTextBox.Clear();
            modelTextBox.Clear();
            priceTextBox.Clear();

            //Reset the focus.
            brandTextBox.Focus();
        }

        private void phoneListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Get the index of the selected items.
            int index = phoneListBox.SelectedIndex;

            //Display the selected item's price.
            MessageBox.Show(phonelist[index].Price.ToString("c"));
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
